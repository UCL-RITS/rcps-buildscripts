/* src/config.h.  Generated from config.h.in by configure.  */
/* Define as 1 if GSL is found */
#undef HAVE_GSL_HEADER
