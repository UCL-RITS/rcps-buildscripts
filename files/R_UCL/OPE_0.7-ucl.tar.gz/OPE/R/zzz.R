.First.lib <- function(libname, pkgname) {
  cat("Package \'OPE\' loaded.  Type ?OPE for help.\n")
}
