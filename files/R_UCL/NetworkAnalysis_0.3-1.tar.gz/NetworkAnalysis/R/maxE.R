maxE <-
function(Nv){
# Equivalent to combination of 2 in Nv.
# i.e. Nv!/((Nv-2)!2!)
return(Nv*(Nv-1)/2)
}# maxE

